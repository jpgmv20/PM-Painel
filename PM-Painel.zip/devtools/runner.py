"""
runner.py

Coordenador principal do ambiente de desenvolvimento.
"""

from __future__ import annotations

import time
from pathlib import Path

from devtools.config import CONFIG
from devtools.state import DevelopmentState
from devtools.logger import Logger
from devtools.events import EVENTS

from devtools.validator import ProjectValidator
from devtools.process import ProcessManager
from devtools.watcher import FileWatcher
from devtools.hotreload import HotReloadManager
from devtools.plugins import PluginManager
from devtools.profiler import Profiler
from devtools.commands import CommandManager
from devtools.console import DevelopmentConsole


class DevelopmentRunner:

    def __init__(self):

        self.project_root = CONFIG.project_root.resolve()

        self.main_file = self.project_root / CONFIG.main_file

        self.running = False

        self.state = DevelopmentState()

        self.state.project_root = self.project_root
        self.state.main_file = self.main_file

        self.validator = ProjectValidator(
            self.project_root
        )

        self.profiler = Profiler()

        self.process = ProcessManager(
            self.main_file,
            self.state
        )

        self.watcher = FileWatcher(self)

        self.hotreload = HotReloadManager(self)

        self.plugins = PluginManager(
            self.project_root
        )

        self.commands = CommandManager(self)

        self.console = DevelopmentConsole(
            self.commands
        )

    # =====================================================

    def start(self):

        Logger.info(
            "Inicializando ambiente..."
        )

        ok, error = self.validator.validate()

        if not ok:

            Logger.error(error)

            return

        self.running = True

        self.profiler.start()

        self.commands.register_default()

        self.plugins.load_all()

        self.hotreload.start()

        self.process.start()

        self.watcher.start()

        self.console.start()

        self.profiler.finish_startup(
            self.state
        )

        EVENTS.emit(
            "app_started"
        )

        Logger.success(
            "Ambiente iniciado."
        )

        self.loop()

    # =====================================================

    def loop(self):

        try:

            while self.running:

                if not self.process.running():

                    Logger.warning(
                        "Aplicação encerrada."
                    )

                    break

                time.sleep(0.2)

        except KeyboardInterrupt:

            Logger.warning(
                "CTRL+C recebido."
            )

        finally:

            self.shutdown()

    # =====================================================

    def restart(self, reason=""):

        Logger.warning(
            f"Restart solicitado: {reason}"
        )

        self.process.restart()

    # =====================================================

    def shutdown(self):

        if not self.running:

            return

        self.running = False

        Logger.info(
            "Encerrando ambiente..."
        )

        self.watcher.stop()

        self.console.stop()

        self.process.stop()

        EVENTS.clear()

        Logger.success(
            "Ambiente encerrado."
        )