"""
state.py

Estado compartilhado do ambiente de desenvolvimento.
"""

from __future__ import annotations

import time
from pathlib import Path


class DevelopmentState:

    def __init__(self):

        # =================================================
        # Projeto
        # =================================================

        self.project_root: Path | None = None

        self.main_file: Path | None = None

        # =================================================
        # Processo
        # =================================================

        self.process_id: int | None = None

        self.process_running = False

        self.process_start_time = None

        # =================================================
        # Estatísticas
        # =================================================

        self.process_restart_count = 0

        self.watcher_reload_count = 0

        self.hot_reload_count = 0

        self.files_changed = 0

        # =================================================
        # Performance
        # =================================================

        self.startup_time = 0.0

        # =================================================
        # Estado interno
        # =================================================

        self.last_changed_file = None

    # =====================================================
    # Processo
    # =====================================================

    def register_process(self, pid):

        self.process_id = pid

        self.process_running = True

        self.process_start_time = time.time()

    def stop_process(self):

        self.process_running = False

        self.process_id = None

    # =====================================================
    # Reinício
    # =====================================================

    def register_restart(self):

        self.process_restart_count += 1

    # =====================================================
    # Hot Reload
    # =====================================================

    def register_hot_reload(self, file):

        self.hot_reload_count += 1

        self.files_changed += 1

        self.last_changed_file = Path(file)

    # =====================================================
    # Watcher
    # =====================================================

    def register_watcher_reload(self):

        self.watcher_reload_count += 1

    # =====================================================
    # Startup
    # =====================================================

    def register_startup(self, seconds):

        self.startup_time = seconds

    # =====================================================
    # Informações
    # =====================================================

    @property
    def uptime(self):

        if self.process_start_time is None:

            return 0.0

        return time.time() - self.process_start_time

    # =====================================================
    # Serialização
    # =====================================================

    def as_dict(self):

        return {

            "pid": self.process_id,

            "running": self.process_running,

            "uptime": self.uptime,

            "startup_time": self.startup_time,

            "restarts": self.process_restart_count,

            "hot_reloads": self.hot_reload_count,

            "watcher_reloads": self.watcher_reload_count,

            "files_changed": self.files_changed,

            "last_file": str(self.last_changed_file)
            if self.last_changed_file
            else None,
        }