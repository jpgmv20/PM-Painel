"""
plugins.py

Sistema de plugins do ambiente.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path

from devtools.config import CONFIG
from devtools.logger import Logger


class PluginManager:

    def __init__(self, project_root):

        self.project_root = project_root

        self.plugins_path = (
            project_root /
            CONFIG.plugins_directory
        )

        self.loaded_plugins = {}

    # =====================================================
    # Carregar todos
    # =====================================================

    def load_all(self):

        if not CONFIG.enable_plugins:

            Logger.warning(
                "Plugins desativados."
            )

            return


        if not self.plugins_path.exists():

            self.plugins_path.mkdir(
                exist_ok=True
            )

            Logger.info(
                "Pasta de plugins criada."
            )

            return


        for file in self.plugins_path.glob("*.py"):

            if file.name.startswith("_"):

                continue

            self.load(file)

    # =====================================================
    # Carregar plugin
    # =====================================================

    def load(self, file: Path):

        name = file.stem


        try:

            spec = importlib.util.spec_from_file_location(

                name,

                file

            )


            if spec is None:

                raise Exception(
                    "Não foi possível criar spec."
                )


            module = importlib.util.module_from_spec(
                spec
            )


            spec.loader.exec_module(
                module
            )


            self.loaded_plugins[name] = {

                "module": module,

                "file": file,

                "enabled": True

            }


            Logger.success(
                f"Plugin carregado: {name}"
            )


            self._start_plugin(
                module
            )


        except Exception as error:


            Logger.error(

                f"Erro carregando plugin {name}: {error}"

            )

    # =====================================================
    # Inicializar plugin
    # =====================================================

    def _start_plugin(self, module):


        start = getattr(

            module,

            "setup",

            None

        )


        if callable(start):

            start()



    # =====================================================
    # Descarregar
    # =====================================================

    def unload(self, name):


        plugin = self.loaded_plugins.get(
            name
        )


        if plugin is None:

            return


        module = plugin["module"]


        stop = getattr(

            module,

            "shutdown",

            None

        )


        if callable(stop):

            stop()


        del self.loaded_plugins[name]


        Logger.info(

            f"Plugin removido: {name}"

        )


    # =====================================================
    # Lista plugins
    # =====================================================

    def list(self):

        return list(
            self.loaded_plugins.keys()
        )


    # =====================================================
    # Status
    # =====================================================

    def status(self):

        return {

            name: data["enabled"]

            for name, data

            in self.loaded_plugins.items()

        }