"""
console.py

Console interativo do ambiente de desenvolvimento.
"""

from __future__ import annotations

import threading

from devtools.config import CONFIG
from devtools.logger import Logger


class DevelopmentConsole:

    def __init__(self, commands):

        self.commands = commands

        self.running = False

        self.thread = None


    # =====================================================
    # Iniciar console
    # =====================================================

    def start(self):

        if not CONFIG.enable_console:

            Logger.warning(
                "Console desativado."
            )

            return


        if self.running:

            return


        self.running = True


        self.thread = threading.Thread(

            target=self._loop,

            daemon=True

        )


        self.thread.start()


        Logger.success(
            "Console iniciado."
        )


    # =====================================================
    # Loop
    # =====================================================

    def _loop(self):

        while self.running:

            try:

                command = input(
                    CONFIG.console_prompt
                )


                self.commands.execute(
                    command
                )


            except EOFError:

                break


            except KeyboardInterrupt:

                break


            except Exception as error:

                Logger.error(

                    f"Erro no console: {error}"

                )


    # =====================================================
    # Parar
    # =====================================================

    def stop(self):

        self.running = False