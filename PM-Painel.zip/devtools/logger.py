"""
logger.py

Sistema de logs do ambiente de desenvolvimento.
"""

from __future__ import annotations

import threading
from collections import deque
from datetime import datetime
from pathlib import Path

from devtools.config import CONFIG


class Logger:

    _lock = threading.RLock()

    _history = deque(maxlen=500)

    _log_file = None

    # =====================================================
    # Inicialização
    # =====================================================

    @classmethod
    def setup(cls):

        if not CONFIG.save_logs:
            return

        CONFIG.logs_path.mkdir(
            exist_ok=True
        )

        filename = datetime.now().strftime(
            "%Y-%m-%d_%H-%M-%S.log"
        )

        cls._log_file = (
            CONFIG.logs_path / filename
        )

    # =====================================================
    # Escrita
    # =====================================================

    @classmethod
    def _write(cls, level, message):

        now = datetime.now().strftime(
            "%d/%m/%Y %H:%M:%S"
        )

        line = f"[{now}] [{level}] {message}"

        with cls._lock:

            print(line)

            cls._history.append(line)

            if cls._log_file is not None:

                with open(

                    cls._log_file,

                    "a",

                    encoding="utf-8"

                ) as f:

                    f.write(line + "\n")

    # =====================================================
    # Níveis
    # =====================================================

    @classmethod
    def debug(cls, message):

        if CONFIG.enable_debug:

            cls._write(
                "DEBUG",
                message
            )

    @classmethod
    def info(cls, message):

        cls._write(
            "INFO",
            message
        )

    @classmethod
    def success(cls, message):

        cls._write(
            "SUCCESS",
            message
        )

    @classmethod
    def warning(cls, message):

        cls._write(
            "WARNING",
            message
        )

    @classmethod
    def error(cls, message):

        cls._write(
            "ERROR",
            message
        )

    # =====================================================
    # Banner
    # =====================================================

    @classmethod
    def banner(cls):

        print()

        print("=" * 60)

        print()

        print("                 PM-PAINEL DEV")

        print()

        print("          Kivy Development Environment")

        print()

        print("=" * 60)

        print()

    # =====================================================
    # Caixa
    # =====================================================

    @classmethod
    def box(cls, title, *lines):

        width = 60

        print()

        print("=" * width)

        print(title.center(width))

        print("=" * width)

        for line in lines:

            print(line)

        print("=" * width)

        print()

    # =====================================================
    # Histórico
    # =====================================================

    @classmethod
    def last(cls, amount=20):

        return list(cls._history)[-amount:]