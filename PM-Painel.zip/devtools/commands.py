"""
commands.py

Sistema de comandos do console.
"""

from __future__ import annotations

from devtools.logger import Logger


class CommandManager:

    def __init__(self, runner):

        self.runner = runner

        self.commands = {}


    # =====================================================
    # Registrar comando
    # =====================================================

    def register(self, name, callback, description=""):

        self.commands[name] = {

            "callback": callback,

            "description": description

        }


        Logger.debug(
            f"Comando registrado: {name}"
        )


    # =====================================================
    # Comandos padrão
    # =====================================================

    def register_default(self):

        self.register(

            "status",

            self.status,

            "Mostra estado do ambiente."

        )


        self.register(

            "reload",

            self.reload,

            "Recarrega arquivos KV."

        )


        self.register(

            "plugins",

            self.plugins,

            "Lista plugins ativos."

        )


        self.register(

            "logs",

            self.logs,

            "Mostra logs recentes."

        )


        self.register(

            "profile",

            self.profile,

            "Mostra desempenho."

        )


        self.register(

            "help",

            self.help,

            "Mostra comandos disponíveis."

        )


    # =====================================================
    # Executar
    # =====================================================

    def execute(self, command):

        parts = command.strip().split()


        if not parts:

            return


        name = parts[0]


        data = self.commands.get(name)


        if data is None:

            Logger.warning(

                f"Comando desconhecido: {name}"

            )

            return


        try:

            args = parts[1:]


            return data["callback"](
                *args
            )


        except Exception as error:

            Logger.error(

                f"Erro executando comando {name}: {error}"

            )


    # =====================================================
    # STATUS
    # =====================================================

    def status(self):

        state = self.runner.state


        Logger.box(

            "STATUS",

            f"PID: {state.process_id}",

            f"Executando: {state.process_running}",

            f"Restarts: {state.process_restart_count}",

            f"Hot Reloads: {state.hot_reload_count}"

        )


    # =====================================================
    # RELOAD
    # =====================================================

    def reload(self):

        self.runner.hotreload.load_project_kv()


    # =====================================================
    # PLUGINS
    # =====================================================

    def plugins(self):

        plugins = self.runner.plugins.list()


        Logger.box(

            "PLUGINS",

            *plugins

        )


    # =====================================================
    # LOGS
    # =====================================================

    def logs(self):

        for line in Logger.last():

            print(line)


    # =====================================================
    # PROFILE
    # =====================================================

    def profile(self):

        self.runner.profiler.print_report()


    # =====================================================
    # HELP
    # =====================================================

    def help(self):

        Logger.box(

            "COMMANDS",

            *[

                f"{name} - {data['description']}"

                for name, data

                in self.commands.items()

            ]

        )