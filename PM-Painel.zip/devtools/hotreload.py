"""
hotreload.py

Gerencia o Hot Reload do ambiente.
"""

from pathlib import Path

from kivy.lang import Builder

from devtools.config import CONFIG
from devtools.events import EVENTS
from devtools.logger import Logger
from devtools.widgets import WIDGETS


class HotReloadManager:

    def __init__(self, runner):

        self.runner = runner

        self.loaded_files = set()

    # =====================================================
    # Inicialização
    # =====================================================

    def start(self):

        EVENTS.on(
            "file_changed",
            self.on_file_changed
        )

        Logger.debug(
            "Hot Reload iniciado."
        )

        self.load_project_kv()

    # =====================================================
    # Carregar todos os KV
    # =====================================================

    def load_project_kv(self):

        root = self.runner.project_root

        count = 0

        for file in root.rglob("*.kv"):

            if self.ignore(file):
                continue

            self.load(file)

            count += 1

        Logger.success(
            f"{count} arquivo(s) KV carregado(s)."
        )

    # =====================================================
    # Ignorar
    # =====================================================

    def ignore(self, file: Path):

        for part in file.parts:

            if CONFIG.is_ignored_directory(part):
                return True

        return False

    # =====================================================
    # Carregar
    # =====================================================

    def load(self, file: Path):

        file = file.resolve()

        if file in self.loaded_files:
            return

        Builder.load_file(str(file))

        self.loaded_files.add(file)

        Logger.info(
            f"KV carregado: {file.name}"
        )

    # =====================================================
    # Arquivo alterado
    # =====================================================

    def on_file_changed(self, path):

        path = Path(path)

        suffix = path.suffix.lower()

        if suffix == ".kv":

            self.reload_kv(path)

            return

        if suffix == ".py":

            Logger.warning(
                "Arquivo Python alterado."
            )

            self.runner.restart(
                "Arquivo Python alterado."
            )

            return

    # =====================================================
    # Reload KV
    # =====================================================

    def reload_kv(self, file):

        Logger.info(
            f"Hot Reload: {file.name}"
        )

        try:

            try:
                Builder.unload_file(
                    str(file)
                )
            except Exception:
                pass

            Builder.load_file(
                str(file)
            )

            WIDGETS.reload()

            EVENTS.emit(
                "kv_reloaded",
                file
            )

            Logger.success(
                f"{file.name} atualizado."
            )

        except Exception as error:

            Logger.error(
                f"Erro no Hot Reload: {error}"
            )