"""
widgets.py

Gerenciador de widgets registrados no ambiente.
"""

from __future__ import annotations

from devtools.logger import Logger


class WidgetManager:

    def __init__(self):

        self.widgets = {}


    # =====================================================
    # Registrar widget
    # =====================================================

    def register(self, name, widget):

        self.widgets[name] = widget

        Logger.debug(
            f"Widget registrado: {name}"
        )


    # =====================================================
    # Remover widget
    # =====================================================

    def unregister(self, name):

        if name in self.widgets:

            del self.widgets[name]

            Logger.debug(
                f"Widget removido: {name}"
            )


    # =====================================================
    # Buscar widget
    # =====================================================

    def get(self, name):

        return self.widgets.get(name)


    # =====================================================
    # Atualizar widgets
    # =====================================================

    def reload(self):

        Logger.debug(
            "Atualizando widgets registrados."
        )


        for name, widget in self.widgets.items():

            try:

                callback = getattr(

                    widget,

                    "on_reload",

                    None

                )


                if callable(callback):

                    callback()


            except Exception as error:

                Logger.error(

                    f"Erro atualizando widget {name}: {error}"

                )


    # =====================================================
    # Lista widgets
    # =====================================================

    def list(self):

        return list(
            self.widgets.keys()
        )


    # =====================================================
    # Limpar
    # =====================================================

    def clear(self):

        self.widgets.clear()


WIDGETS = WidgetManager()