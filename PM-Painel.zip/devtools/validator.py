"""
validator.py

Validação inicial do projeto antes de iniciar o ambiente.
"""

from __future__ import annotations

from pathlib import Path

from devtools.config import CONFIG
from devtools.logger import Logger


class ProjectValidator:

    def __init__(self, project_root):

        self.project_root = Path(
            project_root
        ).resolve()


    # =====================================================
    # Validação principal
    # =====================================================

    def validate(self):

        checks = [

            self.check_root,

            self.check_main_file,

            self.check_python_environment,

        ]


        for check in checks:

            result, message = check()


            if not result:

                return False, message


        Logger.success(
            "Projeto validado."
        )


        return True, None


    # =====================================================
    # Pasta do projeto
    # =====================================================

    def check_root(self):

        if not self.project_root.exists():

            return False, (

                "Pasta do projeto não encontrada."

            )


        return True, None


    # =====================================================
    # Arquivo principal
    # =====================================================

    def check_main_file(self):

        main = (

            self.project_root

            /

            CONFIG.main_file

        )


        if not main.exists():

            return False, (

                f"Arquivo principal não encontrado: {main.name}"

            )


        return True, None


    # =====================================================
    # Ambiente Python
    # =====================================================

    def check_python_environment(self):

        try:

            import kivy


        except ImportError:

            return False, (

                "Kivy não está instalado neste ambiente."

            )


        return True, None