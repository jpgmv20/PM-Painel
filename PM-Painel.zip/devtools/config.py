"""
config.py

Configuração central do ambiente de desenvolvimento.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class DevelopmentConfig:

    # =====================================================
    # Projeto
    # =====================================================

    project_root: Path = field(
        default_factory=lambda: Path.cwd().resolve()
    )

    main_file: str = "main.py"

    # =====================================================
    # Watcher
    # =====================================================

    debounce_time: float = 0.30

    watch_extensions: tuple = (
        ".py",
        ".kv",
        ".json",
        ".yaml",
        ".yml",
        ".ini",
        ".toml",
    )

    ignored_directories: tuple = (

        "__pycache__",

        ".git",

        ".idea",

        ".vscode",

        ".pytest_cache",

        ".mypy_cache",

        "build",

        "dist",

        ".venv",

        "venv",

        "kivy_venv",

        "site-packages",

        "examples",

        "share",

        "logs",
    )

    # =====================================================
    # Hot Reload
    # =====================================================

    enable_hot_reload: bool = True

    enable_python_restart: bool = True

    enable_widget_reload: bool = True

    # =====================================================
    # Console
    # =====================================================

    enable_console: bool = True

    console_prompt: str = "PM> "

    # =====================================================
    # Plugins
    # =====================================================

    plugins_directory: str = "plugins"

    enable_plugins: bool = True

    # =====================================================
    # Logs
    # =====================================================

    enable_debug: bool = True

    save_logs: bool = True

    log_directory: str = "logs"

    # =====================================================
    # Utilidades
    # =====================================================

    @property
    def plugins_path(self):

        return self.project_root / self.plugins_directory

    @property
    def logs_path(self):

        return self.project_root / self.log_directory

    @property
    def main_path(self):

        return self.project_root / self.main_file

    # =====================================================
    # Diretórios ignorados
    # =====================================================

    def is_ignored_directory(self, directory: str):

        return directory in self.ignored_directories

    # =====================================================
    # Arquivo observado
    # =====================================================

    def should_watch(self, path: Path):

        if path.suffix.lower() not in self.watch_extensions:
            return False

        for part in path.parts:

            if self.is_ignored_directory(part):
                return False

        return True


CONFIG = DevelopmentConfig()