"""
process.py

Gerenciador do processo principal da aplicação.
"""

from __future__ import annotations

import subprocess
import sys
import threading
from pathlib import Path

from devtools.logger import Logger


class ProcessManager:

    def __init__(self, main_file: Path, state):

        self.main_file = Path(main_file)
        self.state = state

        self.process = None

        self.stdout_thread = None

        self.lock = threading.RLock()

    # =====================================================
    # Iniciar
    # =====================================================

    def start(self):

        with self.lock:

            if self.running():
                return

            Logger.info(
                f"Iniciando {self.main_file.name}"
            )

            self.process = subprocess.Popen(

                [
                    sys.executable,
                    str(self.main_file)
                ],

                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,

                universal_newlines=True,

                encoding="utf-8",

                errors="replace",

                bufsize=1

            )

            self.state.register_process(
                self.process.pid
            )

            self.stdout_thread = threading.Thread(

                target=self._stdout_loop,

                daemon=True

            )

            self.stdout_thread.start()

            Logger.success(
                f"Kivy iniciado | PID: {self.process.pid}"
            )

    # =====================================================
    # Ler saída
    # =====================================================

    def _stdout_loop(self):

        if self.process is None:
            return

        stream = self.process.stdout

        if stream is None:
            return

        try:

            while self.running():

                line = stream.readline()

                if not line:

                    break

                print(
                    line.rstrip()
                )

        except Exception as error:

            Logger.error(
                f"Erro lendo stdout: {error}"
            )

    # =====================================================
    # Status
    # =====================================================

    def running(self):

        return (

            self.process is not None

            and

            self.process.poll() is None

        )

    # =====================================================
    # Encerrar
    # =====================================================

    def stop(self):

        with self.lock:

            if not self.running():
                return

            Logger.info(
                "Encerrando aplicação..."
            )

            self.process.terminate()

            try:

                self.process.wait(timeout=3)

            except subprocess.TimeoutExpired:

                Logger.warning(
                    "Finalizando processo à força..."
                )

                self.process.kill()

                self.process.wait()

            self.state.stop_process()

            self.process = None

    # =====================================================
    # Reiniciar
    # =====================================================

    def restart(self):

        Logger.info(
            "Reiniciando aplicação..."
        )

        self.stop()

        self.state.register_restart()

        self.start()

    # =====================================================
    # Esperar encerramento
    # =====================================================

    def wait(self):

        if self.process is None:
            return

        self.process.wait()