"""
events.py

Barramento de eventos do ambiente de desenvolvimento.
"""

from collections import defaultdict
from threading import RLock

from devtools.logger import Logger


class EventBus:

    def __init__(self):

        self._listeners = defaultdict(list)

        self._lock = RLock()

    # =====================================================
    # Registrar listener
    # =====================================================

    def on(self, event_name, callback):

        with self._lock:

            if callback in self._listeners[event_name]:
                return

            self._listeners[event_name].append(callback)

        Logger.debug(
            f"Listener registrado: {event_name}"
        )

    # =====================================================
    # Remover listener
    # =====================================================

    def off(self, event_name, callback):

        with self._lock:

            listeners = self._listeners.get(event_name)

            if not listeners:
                return

            if callback in listeners:
                listeners.remove(callback)

    # =====================================================
    # Emitir evento
    # =====================================================

    def emit(self, event_name, *args, **kwargs):

        Logger.debug(
            f"Evento emitido: {event_name}"
        )

        with self._lock:
            listeners = list(
                self._listeners.get(event_name, [])
            )

        for callback in listeners:

            try:

                callback(*args, **kwargs)

            except Exception as error:

                Logger.error(
                    f"Erro no listener '{event_name}': {error}"
                )

    # =====================================================
    # Limpar tudo
    # =====================================================

    def clear(self):

        with self._lock:
            self._listeners.clear()

    # =====================================================
    # Informações
    # =====================================================

    def listener_count(self, event_name=None):

        with self._lock:

            if event_name is None:

                return sum(
                    len(lst)
                    for lst in self._listeners.values()
                )

            return len(
                self._listeners.get(event_name, [])
            )


EVENTS = EventBus()