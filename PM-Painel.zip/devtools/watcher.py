"""
watcher.py

Monitora alterações nos arquivos do projeto.
"""

from __future__ import annotations

import time
from pathlib import Path

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

from devtools.config import CONFIG
from devtools.events import EVENTS
from devtools.logger import Logger


class ProjectWatcher(FileSystemEventHandler):

    def __init__(self):

        super().__init__()

        self.last_event = {}

    # =====================================================
    # Arquivo alterado
    # =====================================================

    def on_modified(self, event):

        if event.is_directory:
            return

        path = Path(event.src_path)

        if self.ignore(path):
            return

        now = time.time()

        previous = self.last_event.get(path)

        if previous is not None:

            if now - previous < CONFIG.debounce_time:

                return

        self.last_event[path] = now

        EVENTS.emit(
            "file_changed",
            path
        )

    # =====================================================
    # Ignorar arquivos
    # =====================================================

    def ignore(self, path: Path):

        suffix = path.suffix.lower()

        if suffix not in CONFIG.watch_extensions:
            return True

        for part in path.parts:

            if CONFIG.is_ignored_directory(part):
                return True

        return False


class FileWatcher:

    def __init__(self, runner):

        self.runner = runner

        self.observer = Observer()

        self.handler = ProjectWatcher()

        self.running = False

    # =====================================================
    # Iniciar
    # =====================================================

    def start(self):

        if self.running:
            return

        self.running = True

        self.observer.schedule(

            self.handler,

            str(self.runner.project_root),

            recursive=True

        )

        self.observer.start()

        Logger.success(
            "Watcher iniciado."
        )

    # =====================================================
    # Parar
    # =====================================================

    def stop(self):

        if not self.running:
            return

        self.running = False

        self.observer.stop()

        self.observer.join()

        Logger.success(
            "Watcher encerrado."
        )