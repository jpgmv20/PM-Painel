"""
profiler.py

Sistema de medição de desempenho do ambiente.
"""

from __future__ import annotations

import time

from devtools.logger import Logger


class Profiler:

    def __init__(self):

        self.start_time = None

        self.marks = {}

        self.finished = False


    # =====================================================
    # Iniciar medição
    # =====================================================

    def start(self):

        self.start_time = time.perf_counter()

        self.marks.clear()

        self.finished = False


    # =====================================================
    # Criar marca
    # =====================================================

    def mark(self, name):

        if self.start_time is None:

            return


        self.marks[name] = (
            time.perf_counter()
            -
            self.start_time
        )


    # =====================================================
    # Finalizar startup
    # =====================================================

    def finish_startup(self, state):

        if self.start_time is None:

            return


        elapsed = (
            time.perf_counter()
            -
            self.start_time
        )


        state.register_startup(
            elapsed
        )


        self.finished = True


        Logger.success(
            f"Inicialização: {elapsed:.3f}s"
        )


    # =====================================================
    # Tempo de etapa
    # =====================================================

    def elapsed(self):

        if self.start_time is None:

            return 0


        return (
            time.perf_counter()
            -
            self.start_time
        )


    # =====================================================
    # Relatório
    # =====================================================

    def report(self):

        return {

            "total":

                self.elapsed(),

            "marks":

                self.marks.copy()

        }


    # =====================================================
    # Exibir relatório
    # =====================================================

    def print_report(self):

        Logger.box(

            "PROFILE",

            f"Tempo total: {self.elapsed():.3f}s",

        )


        for name, value in self.marks.items():

            Logger.info(

                f"{name}: {value:.3f}s"

            )