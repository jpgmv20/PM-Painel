"""
dev.py

Ponto de entrada do ambiente de desenvolvimento.
"""

import traceback

from devtools.events import EVENTS
from devtools.logger import Logger
from devtools.runner import DevelopmentRunner


def handle_exception(error):

    Logger.error(
        "Erro não tratado no ambiente."
    )

    Logger.error(str(error))

    traceback.print_exc()

    EVENTS.emit(
        "error",
        error
    )


def main():

    Logger.setup()

    Logger.banner()

    runner = DevelopmentRunner()

    EVENTS.emit(
        "before_start",
        runner
    )

    try:

        runner.start()

    except KeyboardInterrupt:

        Logger.warning(
            "Execução interrompida pelo usuário."
        )

        runner.shutdown()

    except Exception as error:

        handle_exception(error)

        runner.shutdown()


if __name__ == "__main__":

    main()